//
//  ViewController.m
//  MySphero
//
//  Created by Meghana Iyer on 4/18/18.
//  Copyright © 2018 Meghana Iyer. All rights reserved.
//

#import "ViewController.h"
#import <RobotKit/RobotKit.h>
#import <RobotUIKit/RobotUIKit.h>

@interface ViewController ()
@property (strong, nonatomic) RKConvenienceRobot* robot;
@property (strong, nonatomic) RUICalibrateGestureHandler *calibrateHandler;
@property (weak, nonatomic) IBOutlet UISegmentedControl *MySegmentedControl;
@property (weak, nonatomic) IBOutlet UILabel *MyTextLabel;
@property (weak, nonatomic) IBOutlet UILabel *MyColorLabel;
@property (nonatomic, assign) CGPDFInteger shape;

@end
@implementation ViewController
  RKMacroObject *macro;

- (IBAction)Stop:(id)sender {
    [_robot sendCommand:[RKAbortMacroCommand command]];
    [_robot sendCommand:[RKStabilizationCommand commandWithState:RKStabilizationStateOn]];
    [_robot sendCommand:[RKRollCommand commandWithStopAtHeading:0.0]];
    [_robot sendCommand:[RKRGBLEDOutputCommand commandWithRed:1.0 green:1.0 blue:1.0]];
    /*[_robot stop];
    //[_robot setZeroHeading];
    
     [macro addCommand:[RKMCRoll commandWithSpeed:0.0f heading:0 delay:255]];
     macro.mode = RKMacroObjectModeNormal;*/
}

- (IBAction)MyIndexChanged:(id)sender {
   
    switch (_MySegmentedControl.selectedSegmentIndex) {
        case 0:
            _MyTextLabel.text = @"Square was Selected";
            _shape = 1;
            break;
        case 1:
            _MyTextLabel.text = @"Circle was Selected";
            _shape = 2;
            break;
    }
}
- (IBAction)myStart:(id)sender {
    if (_shape == 1){
    //Create a new macro object to send to Sphero
    //RKMacroObject *
    macro= [RKMacroObject new];
    macro.mode = RKMacroObjectModeNormal;
    //RKMacroObject *macro= [RKMacroObject new];
    //Change Color to green
   
    //Sphero drives forward in the 0 angle
    [macro addCommand:[RKMCRoll commandWithSpeed:0.2 heading:0 delay:1000]];
    //Have Sphero to come to stop to make sharp turn
    [macro addCommand:[RKMCWaitUntilStop commandWithDelay:255]];
    //Change Color to blue
   
    //Sphero drives forward in the 90 angle
    [macro addCommand:[RKMCRoll commandWithSpeed:0.2 heading:90 delay:1000]];
    //Have Sphero to come to stop to make sharp turn
    [macro addCommand:[RKMCWaitUntilStop commandWithDelay:255]];
    //Change Color to yellow
    
    //Sphero drives forward in the 180 angle
    [macro addCommand:[RKMCRoll commandWithSpeed:0.2 heading:180 delay:1000]];
    //Have Sphero to come to stop to make sharp turn
    [macro addCommand:[RKMCWaitUntilStop commandWithDelay:255]];
    //Change Color to red
    
    //Sphero drives forward in the 270 angle
    [macro addCommand:[RKMCRoll commandWithSpeed:0.2 heading:270 delay:1000]];
    //Have Sphero to come to stop to make sharp turn
    [macro addCommand:[RKMCWaitUntilStop commandWithDelay:255]];
    //Change Color to white
   
    //Sphero comes to stop in the 0 angle
    [macro addCommand:[RKMCRoll commandWithSpeed:0.0 heading:0 delay:1000]];
    //Send full command dowm to Sphero to play
    // [macro playMacro];
    
    RKMacroPlayer *player = [[RKMacroPlayer alloc] initWithRobot:_robot.robot];
    [player play:macro];
    
    //Release Macro
    //[macro release];
    //[_robot setZeroHeading];
    //[_robot driveWithHeading:90 andVelocity:0.1 andReverse:true];
    }
        else if (_shape == 2){
                RKMacroObject *macro = [RKMacroObject new];
                //Sets loop from slider value
                [macro addCommand:[RKMCLoopFor commandWithRepeats: 3]];
                [macro addCommand:[RKMCRotateOverTime commandWithRotation:360 delay:3000]];
                [macro addCommand:[RKMCRoll commandWithSpeed:0.2 heading:180 delay:3000]];
                //Loop End
                [macro addCommand:[RKMCLoopEnd command]];
                //Send full command dowm to Sphero to play
                RKMacroPlayer *player = [[RKMacroPlayer alloc] initWithRobot:_robot.robot];
                [player play:macro];
            }
        
}





- (IBAction)MyRed:(id)sender {//Sphero Turns Red
    [_robot sendCommand:[RKRGBLEDOutputCommand commandWithRed:1.0f green:.0 blue:.0]];
    _MyColorLabel.text = @"Red was Selected";
    // The valid color values here are 0.0f to 1.0f.
}
- (IBAction)MyOrange:(id)sender {//Sphero Turns Orange
    [_robot sendCommand:[RKRGBLEDOutputCommand commandWithRed:1.0f green:0.5f blue:0]];
    _MyColorLabel.text = @"Orange was Selected";
    // The valid color values here are 0.0f to 1.0f.
}
- (IBAction)MyYellow:(id)sender {//Sphero Turns Yellow
    [_robot sendCommand:[RKRGBLEDOutputCommand commandWithRed:1.0f green:0.75f blue:0]];
    _MyColorLabel.text = @"Yellow was Selected";
    // The valid color values here are 0.0f to 1.0f.
}
- (IBAction)MyGreen:(id)sender {//Sphero Turns Green
    [_robot sendCommand:[RKRGBLEDOutputCommand commandWithRed:0 green:1.0f blue:0]];
    _MyColorLabel.text = @"Green was Selected";
    // The valid color values here are 0.0f to 1.0f.
}
- (IBAction)MyBlue:(id)sender {//Sphero Turns Blue
    [_robot sendCommand:[RKRGBLEDOutputCommand commandWithRed:0 green:0 blue:1.0f]];
    _MyColorLabel.text = @"Blue was Selected";
    // The valid color values here are 0.0f to 1.0f.
}
- (IBAction)MyPurple:(id)sender {//Sphero Turns Purple
    [_robot sendCommand:[RKRGBLEDOutputCommand commandWithRed:0.75f green:0 blue:1.0f]];
    _MyColorLabel.text = @"Purple was Selected";
    // The valid color values here are 0.0f to 1.0f.
}
- (IBAction)MyPink:(id)sender {//Sphero Turns Pink
    [_robot sendCommand:[RKRGBLEDOutputCommand commandWithRed:1.0f green:.0 blue:0.75f]];
    _MyColorLabel.text = @"Pink was Selected";
    // The valid color values here are 0.0f to 1.0f.
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(appWillResignActive:)
                                                 name:UIApplicationWillResignActiveNotification
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(appDidBecomeActive:)
                                                 name:UIApplicationDidBecomeActiveNotification
                                               object:nil];
    
    
    self.calibrateHandler = [[RUICalibrateGestureHandler alloc] initWithView:self.view];
    
    // hook up for robot state changes
    [[RKRobotDiscoveryAgent sharedAgent] addNotificationObserver:self selector:@selector(handleRobotStateChangeNotification:)];
    // Do any additional setup after loading the view, typically from a nib.
}
- (void)appDidBecomeActive:(NSNotification*)notification {
    [RKRobotDiscoveryAgent startDiscovery];
    
}


- (void)appWillResignActive:(NSNotification*)notification {
    [RKRobotDiscoveryAgent stopDiscovery];
    [RKRobotDiscoveryAgent disconnectAll];
}

- (void)handleRobotStateChangeNotification:(RKRobotChangedStateNotification*)n {
    switch(n.type) {
        case RKRobotConnecting:
            [self handleConnecting];
            break;
        case RKRobotOnline: {
            // Do not allow the robot to connect if the application is not running
            RKConvenienceRobot *convenience = [RKConvenienceRobot convenienceWithRobot:n.robot];
            if ([[UIApplication sharedApplication] applicationState] != UIApplicationStateActive) {
                [convenience disconnect];
                return;
            }
            self.robot = convenience;
            [self handleConnected];
            break;
        }
        case RKRobotDisconnected:
            [self handleDisconnected];
            self.robot = nil;
            [RKRobotDiscoveryAgent startDiscovery];
            break;
        default:
            break;
    }
}

- (void)handleConnecting {
    // Handle when a robot is connecting here
}

- (void)handleConnected {
    [_calibrateHandler setRobot:_robot.robot];
}

- (void)handleDisconnected {
    [_calibrateHandler setRobot:nil];
}



- (IBAction)ShapeDetector:(id)sender {
    
}

//- (IBAction)MoveForward:(id)sender {
  //  [_robot driveWithHeading:90 andVelocity:0.5];
//}
//- (IBAction)StopSphero:(id)sender {
  //  [_robot stop];
//}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end


/*
 #import <RobotKit/RobotKit.h>
 #import <RobotUIKit/RobotUIKit.h>
 
 @interface ViewController ()
 @property (strong, nonatomic) RKConvenienceRobot* robot;
 @property (strong, nonatomic) RUICalibrateGestureHandler *calibrateHandler;
 
 @end
 
 @implementation ViewController
 
 - (void)viewDidLoad {
 [super viewDidLoad];
 [[NSNotificationCenter defaultCenter] addObserver:self
 selector:@selector(appWillResignActive:)
 name:UIApplicationWillResignActiveNotification
 object:nil];
 [[NSNotificationCenter defaultCenter] addObserver:self
 selector:@selector(appDidBecomeActive:)
 name:UIApplicationDidBecomeActiveNotification
 object:nil];
 
 
 self.calibrateHandler = [[RUICalibrateGestureHandler alloc] initWithView:self.view];
 
 // hook up for robot state changes
 [[RKRobotDiscoveryAgent sharedAgent] addNotificationObserver:self selector:@selector(handleRobotStateChangeNotification:)];
 // Do any additional setup after loading the view, typically from a nib.
 }
 - (void)appDidBecomeActive:(NSNotification*)notification {
 [RKRobotDiscoveryAgent startDiscovery];
 
 }
 
 
 - (void)appWillResignActive:(NSNotification*)notification {
 [RKRobotDiscoveryAgent stopDiscovery];
 [RKRobotDiscoveryAgent disconnectAll];
 }
 
 - (void)handleRobotStateChangeNotification:(RKRobotChangedStateNotification*)n {
 switch(n.type) {
 case RKRobotConnecting:
 [self handleConnecting];
 break;
 case RKRobotOnline: {
 // Do not allow the robot to connect if the application is not running
 RKConvenienceRobot *convenience = [RKConvenienceRobot convenienceWithRobot:n.robot];
 if ([[UIApplication sharedApplication] applicationState] != UIApplicationStateActive) {
 [convenience disconnect];
 return;
 }
 self.robot = convenience;
 [self handleConnected];
 break;
 }
 case RKRobotDisconnected:
 [self handleDisconnected];
 self.robot = nil;
 [RKRobotDiscoveryAgent startDiscovery];
 break;
 default:
 break;
 }
 }
 
 - (void)handleConnecting {
 // Handle when a robot is connecting here
 }
 
 - (void)handleConnected {
 [_calibrateHandler setRobot:_robot.robot];
 }
 
 - (void)handleDisconnected {
 [_calibrateHandler setRobot:nil];
 }
 
 - (IBAction)MoveForward:(id)sender {
 [_robot driveWithHeading:90 andVelocity:0.5];
 }
 - (IBAction)StopSphero:(id)sender {
 [_robot stop];
 }
 
 - (void)didReceiveMemoryWarning {
 [super didReceiveMemoryWarning];
 // Dispose of any resources that can be recreated.
 }

 */
