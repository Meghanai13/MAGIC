//
//  main.m
//  MySphero
//
//  Created by Meghana Iyer on 4/18/18.
//  Copyright © 2018 Meghana Iyer. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
