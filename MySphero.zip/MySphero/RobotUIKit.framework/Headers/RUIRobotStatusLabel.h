//
//  TARobotStatusLabel.h
//  LeTestDrive
//
//  Created by wes on 4/30/15.
//  Copyright (c) 2015 Orbotix. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <RobotKit/RobotKit.h>

@interface RUIRobotStatusLabel : UILabel

@end
