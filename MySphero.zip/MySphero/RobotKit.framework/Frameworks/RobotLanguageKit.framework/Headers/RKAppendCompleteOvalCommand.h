//
//  Copyright (c) 2014-2015 Orbotix Inc. All rights reserved.
//

#import <RobotCommandKit/RobotCommandKit.h>

@interface RKAppendCompleteOvalCommand : RKDeviceCommand

- (id)initWithData:(NSData *)data;

@end
