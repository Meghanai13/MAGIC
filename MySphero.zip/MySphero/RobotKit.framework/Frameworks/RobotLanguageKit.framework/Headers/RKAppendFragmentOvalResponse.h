//
//  Copyright (c) 2015 Orbotix Inc. All rights reserved.
//

#import <RobotCommandKit/RobotCommandKit.h>

@interface RKAppendFragmentOvalResponse : RKDeviceResponse

@end
