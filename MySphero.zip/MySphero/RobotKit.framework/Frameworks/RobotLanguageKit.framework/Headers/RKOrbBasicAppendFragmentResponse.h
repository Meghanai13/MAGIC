//
//  Copyright (c) 2014 Orbotix Inc. All rights reserved.
//

#import <RobotCommandKit/RKDeviceResponse.h>

@interface RKOrbBasicAppendFragmentResponse : RKDeviceResponse

@end
