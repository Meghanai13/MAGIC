//
//  RKMacroObject+Compatibility.h
//  RobotCompatibilityKit
//
//  Created by Jack Thorp on 7/9/14.
//  Copyright (c) 2014 Orbotix Inc. All rights reserved.
//

#import "RKMacroObject.h"

@interface RKMacroObject (Compatibility)

- (void)playMacro;

@end