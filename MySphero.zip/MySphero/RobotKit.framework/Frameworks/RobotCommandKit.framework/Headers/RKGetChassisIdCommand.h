//
//  Copyright (c) 2014 Orbotix Inc. All rights reserved.
//

#import <RobotCommandKit/RobotCommandKit.h>

@interface RKGetChassisIdCommand : RKDeviceCommand

+(instancetype) command;

@end
