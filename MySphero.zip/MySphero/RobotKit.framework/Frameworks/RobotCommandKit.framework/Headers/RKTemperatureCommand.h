//
//  RKTemperatureCommand.h
//  RobotCommandKit
//
//  Created by Adam Wilson on 5/18/15.
//  Copyright (c) 2015 Orbotix Inc. All rights reserved.
//

#import <RobotCommandKit/RobotCommandKit.h>

@interface RKTemperatureCommand : RKDeviceCommand

+(id) command;

@end
