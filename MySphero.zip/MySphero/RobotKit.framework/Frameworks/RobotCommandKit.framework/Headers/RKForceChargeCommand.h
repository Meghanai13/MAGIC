//
//  RKForceRechargeCommand.h
//  RobotCommandKit
//
//  Created by wes on 7/23/15.
//  Copyright (c) 2015 Orbotix Inc. All rights reserved.
//

#import <RobotCommandKit/RobotCommandKit.h>

@interface RKForceChargeCommand : RKDeviceCommand

+ (id) command;

@end
