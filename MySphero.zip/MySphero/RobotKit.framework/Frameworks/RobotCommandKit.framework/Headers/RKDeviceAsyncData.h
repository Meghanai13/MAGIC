//
//  Copyright 2011-2014 Orbotix Inc. All rights reserved.
//

/*! @file 
 @deprecated - replace with RKAsyncMessage
 */

#import <Foundation/Foundation.h>
#import "RKAsyncMessage.h"

__deprecated_msg("Replaced with RKAsyncMessage.") // replaced with RKAsyncMessage
@interface RKDeviceAsyncData : RKAsyncMessage



@end
