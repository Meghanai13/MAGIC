//
//  RKSetNonPersistentOptionFlagsResponse.h
//  RobotCommandKit
//
//  Created by Jack Thorp on 8/5/14.
//  Copyright (c) 2014 Orbotix Inc. All rights reserved.
//

/*! @file */

#import "RKDeviceResponse.h"

@interface RKSetNonPersistentOptionFlagsResponse : RKDeviceResponse

@end

