//
//  RKWritePersistentPageResponse.h
//  RobotCommandKit
//
//  Created by Hunter Lang on 3/16/15.
//  Copyright (c) 2015 Orbotix Inc. All rights reserved.
//

#import <RobotCommandKit/RobotCommandKit.h>

@interface RKWritePersistentPageResponse : RKDeviceResponse

@end
