//
//  RKReadOdometerCommand.h
//  RobotCommandKit
//
//  Created by wes on 6/30/14.
//  Copyright (c) 2014 Orbotix Inc. All rights reserved.
//

#import <RobotCommandKit/RobotCommandKit.h>

@interface RKReadOdometerCommand : RKDeviceCommand

+(id) command;

@end
