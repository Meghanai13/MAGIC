//
//  RKGetSkuCommand.h
//  RobotCommandKit
//
//  Created by wes on 2/5/15.
//  Copyright (c) 2015 Orbotix Inc. All rights reserved.
//

#import <RobotCommandKit/RobotCommandKit.h>

@interface RKGetSkuCommand : RKDeviceCommand

+ (id) command;

@end
