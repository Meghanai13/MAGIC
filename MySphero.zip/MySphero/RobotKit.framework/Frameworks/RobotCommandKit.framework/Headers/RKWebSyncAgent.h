//
//  Copyright (c) 2014 Orbotix Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RKWebSyncAgent : NSObject

+ (BOOL)recordStats:(NSArray *)stats;

@end
