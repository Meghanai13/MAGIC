//
//  RKNoConnectStrategy.h
//  RobotKitLE
//
//  Created by wes on 11/14/14.
//  Copyright (c) 2014 Orbotix Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RKLeConnectStrategy.h"

@interface RKNoConnectStrategy : NSObject <RKLeConnectStrategy>

@end
