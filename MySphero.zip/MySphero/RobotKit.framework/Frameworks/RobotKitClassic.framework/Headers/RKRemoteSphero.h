//
//  RKRemoteSphero.h
//  RobotKit
//
//  Created by Jon Carroll on 8/9/11.
//  Copyright 2011 Orbotix Inc. All rights reserved.
//

#import <RobotKitClassic/RKRemoteRobot.h>

@interface RKRemoteSphero : RKRemoteRobot {

}

@end
