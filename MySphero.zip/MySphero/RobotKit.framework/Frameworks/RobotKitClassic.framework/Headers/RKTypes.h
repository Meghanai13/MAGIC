//
//  Copyright (c) 2012-2015 Orbotix Inc. All rights reserved.
//

// TYPES FOR CLASSIC ONLY.