//
//  Copyright (c) 2014 Orbotix Inc. All rights reserved.
//

#import "RKConvenienceRobot.h"

@interface RKOllie : RKConvenienceRobot


@end
